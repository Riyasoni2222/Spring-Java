package com.example.StudentSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentSpringbootApplication.class, args);
	}

}
